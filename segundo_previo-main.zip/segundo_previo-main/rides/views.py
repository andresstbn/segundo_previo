from django.contrib.auth import get_user_model
from django.views.generic import TemplateView
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import mixins, permissions, viewsets
from rest_framework.response import Response

from .models import Rating, Trip, Vehicle
from .serializers import (
    RatingSerializer,
    TripSerializer,
    UserSerializer,
    VehicleSerializer,
)

User = get_user_model()


class HomeView(TemplateView):
    """
    Vista de inicio de la aplicación.
    """
    template_name = 'rides/home.html'


class VehicleViewSet(viewsets.ModelViewSet):
    """
    ViewSet para CRUD de vehículos.
    """
    queryset = Vehicle.objects.all()
    serializer_class = VehicleSerializer
    permission_classes = [permissions.IsAuthenticated]


    @action(detail=True, methods=['post'], url_path='toggle-availability')
    def toggle_availability(self, request, pk=None):
        """
        Invierte el estado de disponibilidad del vehículo.
        """
        vehicle = self.get_object()
        driver_status = vehicle.driver
        driver_status.is_available = not driver_status.is_available
        driver_status.save()
        return Response({'is_available': driver_status.is_available}, status=status.HTTP_200_OK)
        
    @action(detail=True, methods=['get'])
    def modelssummary(self, request):
        queryset = Vehicle.objects.values('model', Vehicle.objects.filter(model='model').count())
        serializer = VehicleSerializer(queryset).data
        return Response({'model and count': serializer})
    

class PassengerViewSet(viewsets.ReadOnlyModelViewSet): #Nuevo ViewSet
    """
    ViewSet para gestionar Passengers.

    Soporta filtro por driver con ?passenger=<id>.
    """
    queryset = User.objects.filter(is_passenger=True)
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['passenger']

    @action(detail=True, methods=['get'])
    def trips(self, request, pk=None):
        trips = Rating.objects.filter(trip__driver_id=pk)
        serializer = UserSerializer(trips, many=True)
        return Response(serializer.data)

class TripViewSet(viewsets.ReadOnlyModelViewSet):
    """
    ViewSet para gestionar trips.

    Soporta filtro por driver con ?driver=<id>.
    """
    queryset = Trip.objects.all()
    serializer_class = TripSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['driver']

    @action(detail=False, methods=['get'])
    def active_count(self, request):
        pending_count = Trip.objects.filter(status=Trip.STATUS_PENDING).count()
        ongoing_count = Trip.objects.filter(status=Trip.STATUS_ONGOING).count()
        return Response({
            "pending": pending_count,
            "ongoing": ongoing_count
        }, status=status.HTTP_200_OK)

class DriverViewSet(viewsets.ReadOnlyModelViewSet):
    """
    ViewSet para ver conductores.
    """
    queryset = User.objects.filter(is_driver=True)
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]

    @action(detail=False, methods=['get'])
    def trending(self, request):
        average_score = User.objects.filter(is_driver=True).aggregate(prom=Avg('-Rating.score'))['prom']
        queryset = average_score[:5]
        return Response({
            queryset
        }, status=status.HTTP_200_OK)

class RatingViewSet(
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    mixins.UpdateModelMixin,
    viewsets.GenericViewSet
):
    """
    ViewSet para listar, detallar y actualizar ratings, pero no borrar.
    """
    queryset = Rating.objects.all()
    serializer_class = RatingSerializer
    permission_classes = [permissions.IsAuthenticated]
